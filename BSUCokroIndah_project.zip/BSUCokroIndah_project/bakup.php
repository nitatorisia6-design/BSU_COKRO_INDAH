<?php
// manual SQL export of selected tables
include 'koneksi.php';
if (!isset($_GET['run'])) {
  echo '<!doctype html><html><head><meta charset="utf-8"><title>Backup</title><link rel="stylesheet" href="style.css"></head><body style="padding:24px;"><h2>Backup Data (Manual)</h2><p>This is manual backup: click button to download SQL.</p><a class="nav-link" href="?run=1">Download Backup SQL</a></body></html>';
  exit;
}
// run export
$tables = ['users','jenis_sampah','transaksi'];
$sql = "-- BSUCokroIndah backup\n\n";
foreach($tables as $t) {
  $res = mysqli_query($koneksi, "SHOW CREATE TABLE $t");
  $row = mysqli_fetch_row($res);
  $sql .= "\n-- Table structure for $t\n";
  $sql .= $row[1].";\n\n";
  $data = mysqli_query($koneksi, "SELECT * FROM $t");
  while($r = mysqli_fetch_assoc($data)) {
    $cols = array_keys($r);
    $vals = array_map(function($v){ return addslashes($v); }, array_values($r));
    $sql .= "INSERT INTO $t (`".implode('`,`',$cols)."`) VALUES ('".implode("','",$vals)."');\n";
  }
}
header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="BSUCokroIndah_backup_'.date('Ymd_His').'.sql"');
echo $sql;
exit;
?>

<?php
// Database connection - update if needed
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'BSUCokroIndah';

$koneksi = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>

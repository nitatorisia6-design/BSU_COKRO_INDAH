<?php
session_start();
include 'koneksi.php';

// Jika tombol login ditekan
if (isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Cek di tabel users
    $query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) === 1) {
        $data = mysqli_fetch_assoc($result);

        // Simpan session user
        $_SESSION['user'] = [
            'id_user' => $data['id_user'],
            'nama'    => $data['nama'],
            'role'    => $data['role'],
            'saldo'   => $data['saldo']
        ];

        // Redirect sesuai role
        if ($data['role'] === 'admin') {
            header('Location: admin/dashboard.php');
        } elseif ($data['role'] === 'petugas') {
            header('Location: petugas/dashboard.php');
        } else {
            header('Location: nasabah/dashboard.php');
        }
        exit;

    } else {
        $error = "Username atau password salah!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Bank Sampah</title>
    <link rel="stylesheet" href="style.css"> <!-- KAITKAN CSS DI SINI -->
</head>
<body class="login-body">

    <div class="login-card">
        <h2>BANK SAMPAH UNIT</h2>
        <h2>COKRO INDAH</h2>
        <h3>Login</h2>

        <?php if (!empty($error)): ?>
            <div class="error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="username" placeholder="Username..." required>
            <input type="password" name="password" placeholder="Password..." required>

            <button type="submit" name="login">Login</button>
        </form>
    </div>

</body>
</html>

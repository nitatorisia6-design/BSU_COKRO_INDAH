<?php
if (!isset($_SESSION)) session_start();
$user = $_SESSION['user'] ?? null;
$role = $user['role'] ?? '';
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>BSU Cokro Indah</title>
  <link rel="stylesheet" href="/BSUCokroIndah_project/style.css">
</head>

<body>
<div class="app">

  <div class="sidebar">
    <h3>BSU COKRO INDAH</h3>
    <p class="small">Selamat datang</p>

    <?php if ($role === 'admin'): ?>
        <a class="nav-link" href="/BSUCokroIndah_project/admin/dashboard.php">Beranda</a>
        <a class="nav-link" href="/BSUCokroIndah_project/admin/kelola_akun.php">kelola Akun</a>
        <a class="nav-link" href="/BSUCokroIndah_project/admin/jenis_sampah.php">Jenis Sampah</a>
        <a class="nav-link" href="/BSUCokroIndah_project/admin/laporan.php">Laporan</a>
        <a class="nav-link" href="/BSUCokroIndah_project/admin/pengaturan_sistem.php">Pengaturan Sistem</a>
        <a class="nav-link" href="#" onclick="confirmLogout()">Logout</a>

    <?php elseif ($role === 'petugas'): ?>
        <a class="nav-link" href="/BSUCokroIndah_project/petugas/dashboard.php">Beranda</a>
        <a class="nav-link" href="/BSUCokroIndah_project/petugas/setor_sampah.php">Setor Sampah</a>
        <a class="nav-link" href="/BSUCokroIndah_project/petugas/laporan.php">Laporan</a>
        <a class="nav-link" href="#" onclick="confirmLogout()">Logout</a>


    <?php elseif ($role === 'nasabah'): ?>
        <a class="nav-link" href="/BSUCokroIndah_project/nasabah/dashboard.php">Beranda</a>
        <a class="nav-link" href="/BSUCokroIndah_project/nasabah/riwayat_setoran.php">Riwayat Setoran</a>
        <a class="nav-link" href="/BSUCokroIndah_project/nasabah/saldo.php">Saldo</a>
        <a class="nav-link" href="#" onclick="confirmLogout()">Logout</a>


    <?php endif; ?>

  </div>

  <div style="flex:1">
    <div class="header">
      <div></div>
      <div>
        Halo, <?= htmlspecialchars($user['nama'] ?? 'Guest') ?>
        (<?= $role ?>)
      </div>
    </div>

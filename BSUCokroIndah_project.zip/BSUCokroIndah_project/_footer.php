  </div> <!-- main area -->
</div> <!-- app -->
<script>
function confirmLogout() {
    if (confirm("Apakah Anda yakin ingin logout?")) {
        window.location.href = "/BSUCokroIndah_project/logout.php";
    }
}
</script>

</body>
</html>

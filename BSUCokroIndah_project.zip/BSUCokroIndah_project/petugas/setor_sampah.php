<?php
session_start();
include '../koneksi.php';

// Cek role
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'petugas') {
    header('Location: ../index.php');
    exit;
}

// =======================
//  PROSES SIMPAN SETORAN
// =======================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $id_user  = (int)$_POST['id_user'];
    $id_jenis = (int)$_POST['id_jenis'];
    $berat    = floatval($_POST['berat']);

    // Ambil harga dari jenis sampah
    $jenis = mysqli_fetch_assoc(mysqli_query($koneksi,
        "SELECT harga FROM jenis_sampah WHERE id_jenis=$id_jenis"
    ));

    $harga = $jenis['harga'];
    $total = $harga * $berat;

    // INSERT ke tabel transaksi
    mysqli_query($koneksi,
        "INSERT INTO transaksi 
        (id_user, id_jenis, berat, harga, total, jenis_transaksi, petugas_input, tanggal)
        VALUES 
        ($id_user, $id_jenis, $berat, $harga, $total, 'setoran', {$_SESSION['user']['id_user']}, NOW())"
    );

    // UPDATE saldo nasabah
    mysqli_query($koneksi,
        "UPDATE users SET saldo = saldo + $total WHERE id_user = $id_user"
    );

    echo "<script>
            alert('Setoran berhasil disimpan!');
            window.location='transaksi.php';
          </script>";
    exit;
}

// ====================================
//  AMBIL DATA UNTUK FORM SETOR SAMPAH
// ====================================

$nasabah = mysqli_query($koneksi, "SELECT id_user, nama FROM users WHERE role='nasabah'");
$jenis_sampah = mysqli_query($koneksi, "SELECT id_jenis, nama_jenis, harga FROM jenis_sampah");

?>

<?php include '../_header.php'; ?>

<div class="content">
    <h2>Setor Sampah</h2>

    <div class="card" style="max-width:600px; margin-top:20px;">

        <form method="POST" action="setor_sampah.php">

            <label>Nama Nasabah</label>
            <select name="id_user" class="form" required>
                <option value="">-- Pilih Nasabah --</option>
                <?php while($n = mysqli_fetch_assoc($nasabah)): ?>
                    <option value="<?= $n['id_user'] ?>"><?= $n['nama'] ?></option>
                <?php endwhile; ?>
            </select>

            <label>Jenis Sampah</label>
            <select name="id_jenis" class="form" required>
                <option value="">-- Pilih Jenis Sampah --</option>
                <?php while($j = mysqli_fetch_assoc($jenis_sampah)): ?>
                    <option value="<?= $j['id_jenis'] ?>">
                        <?= $j['nama_jenis'] ?> - Rp <?= number_format($j['harga']) ?>/Kg
                    </option>
                <?php endwhile; ?>
            </select>

            <label>Berat Sampah (Kg)</label>
            <input type="number" step="0.1" name="berat" class="form" required>

            <button type="submit" 
                style="padding:10px 16px; background:#0b2a5c; color:white; border:none; border-radius:6px; margin-top:10px;">
                Simpan Setoran
            </button>

        </form>

    </div>
</div>

<?php include '../_footer.php'; ?>

<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) 
    || !in_array($_SESSION['user']['role'], ['admin', 'petugas'])) {

    header('Location: ../index.php');
    exit;
}

// Query SETORAN
$qSetoran = mysqli_query($koneksi,
    "SELECT 
        t.id_transaksi AS id,
        t.tanggal,
        u.nama AS nasabah,
        j.nama_jenis AS jenis,
        CONCAT(t.berat,' Kg') AS keterangan,
        t.total AS nominal,
        'Setoran' AS jenis_transaksi,
        p.nama AS petugas,
        '-' AS status
     FROM transaksi t
     LEFT JOIN users u ON t.id_user = u.id_user
     LEFT JOIN jenis_sampah j ON t.id_jenis = j.id_jenis
     LEFT JOIN users p ON t.petugas_input = p.id_user"
);

$qTarik = mysqli_query($koneksi,
    "SELECT 
        pen.id_penarikan AS id,
        pen.tanggal,
        u.nama AS nasabah,
        'Penarikan Saldo' AS jenis,
        '-' AS keterangan,
        pen.nominal AS nominal,
        'Penarikan' AS jenis_transaksi,
        pen.status,
        '-' AS petugas
     FROM penarikan pen
     LEFT JOIN users u ON pen.id_user = u.id_user"
);


// Gabungkan hasil
$data = [];
while($r = mysqli_fetch_assoc($qSetoran)) $data[] = $r;
while($r = mysqli_fetch_assoc($qTarik))   $data[] = $r;

// Urut berdasarkan tanggal DESC
usort($data, function($a, $b) {
    return strtotime($b['tanggal']) - strtotime($a['tanggal']);
});
?>
<?php include '../_header.php'; ?>

<div class="content">
  <h2>Data Semua Transaksi</h2>

  <table class="table">
    <tr>
      <th>ID</th>
      <th>Tanggal</th>
      <th>Nasabah</th>
      <th>Jenis</th>
      <th>Keterangan</th>
      <th>Nominal</th>
      <th>Jenis Transaksi</th>
      <th>Status</th>
      <th>Petugas</th>
    </tr>

    <?php foreach($data as $r): ?>
    <tr>
      <td><?= $r['id'] ?></td>
      <td><?= $r['tanggal'] ?></td>
      <td><?= $r['nasabah'] ?></td>
      <td><?= $r['jenis'] ?></td>
      <td><?= $r['keterangan'] ?></td>
      <td>Rp <?= number_format($r['nominal']) ?></td>
      <td><?= $r['jenis_transaksi'] ?></td>
      <td><?= $r['status'] ?></td>
      <td><?= $r['petugas'] ?></td>
    </tr>
    <?php endforeach; ?>

  </table>
</div>

<?php include '../_footer.php'; ?>

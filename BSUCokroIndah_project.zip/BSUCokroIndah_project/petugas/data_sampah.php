<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'petugas') {
    header('Location: ../index.php');
    exit;
}

$q = mysqli_query($koneksi, "SELECT * FROM jenis_sampah");
?>
<?php include '../_header.php'; ?>

<div class="content">
  <h2>Data Sampah</h2>

  <table class="table">
    <tr>
      <th>ID</th>
      <th>Jenis Sampah</th>
      <th>Harga per Kg</th>
    </tr>

    <?php while($r = mysqli_fetch_assoc($q)): ?>
    <tr>
      <td><?= $r['id_jenis'] ?></td>
      <td><?= $r['nama_jenis'] ?></td>
      <td>Rp <?= number_format($r['harga']) ?></td>
    </tr>
    <?php endwhile; ?>

  </table>
</div>

<?php include '../_footer.php'; ?>

<?php
session_start();
include '../koneksi.php';

// Cek login petugas
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'petugas') {
    header('Location: ../index.php');
    exit;
}

/* ==========================================================
   SETUJUI PENARIKAN
   ========================================================== */
if (isset($_GET['setujui'])) {

    $id_penarikan = $_GET['setujui'];

    // Ambil data penarikan
    $r = mysqli_fetch_assoc(mysqli_query($koneksi,
        "SELECT * FROM penarikan WHERE id_penarikan='$id_penarikan'"
    ));

    if ($r && strtolower($r['status']) == "menunggu") {

        $id_user = $r['id_user'];
        $nominal = $r['nominal'];

        // Ambil saldo dan total berat user
        $u = mysqli_fetch_assoc(mysqli_query($koneksi,
            "SELECT saldo, total_berat FROM users WHERE id_user='$id_user'"
        ));

        $saldo = $u['saldo'];
        $total_berat = $u['total_berat'];

        if ($saldo >= $nominal) {

            // Hitung harga per kg (menghindari pembagian 0)
            $harga_perkg = ($saldo > 0 && $total_berat > 0) ? $saldo / $total_berat : 0;

            // Jika gagal hitung, berat tidak dikurangi
            $berat_dikurangi = ($harga_perkg > 0) ? $nominal / $harga_perkg : 0;

            $berat_baru = max(0, $total_berat - $berat_dikurangi);
            $saldo_baru = $saldo - $nominal;

            // Update saldo & berat user
            mysqli_query($koneksi,
                "UPDATE users SET saldo='$saldo_baru', total_berat='$berat_baru'
                 WHERE id_user='$id_user'"
            );

            // Update status penarikan
            mysqli_query($koneksi,
                "UPDATE penarikan SET status='Disetujui'
                 WHERE id_penarikan='$id_penarikan'"
            );

            echo "<script>alert('Penarikan disetujui!');window.location='laporan.php';</script>";
        } else {
            echo "<script>alert('Saldo tidak mencukupi!');window.location='laporan.php';</script>";
        }

    } else {
        echo "<script>alert('Data tidak valid atau sudah diproses!');window.location='laporan.php';</script>";
    }
}


/* ==========================================================
   TOLAK PENARIKAN
   ========================================================== */
if (isset($_GET['tolak'])) {

    $id_penarikan = $_GET['tolak'];

    mysqli_query($koneksi,
        "UPDATE penarikan SET status='Ditolak'
         WHERE id_penarikan='$id_penarikan'"
    );

    echo "<script>alert('Penarikan ditolak.');window.location='laporan.php';</script>";
}


/* ==========================================================
   DATA PERMINTAAN PENARIKAN
   ========================================================== */
$penarikan = mysqli_query($koneksi,
    "SELECT p.*, u.nama
     FROM penarikan p
     LEFT JOIN users u ON p.id_user=u.id_user
     ORDER BY p.tanggal DESC"
);


/* ==========================================================
   FILTER LAPORAN SETORAN
   ========================================================== */
$hasil = false;

if (isset($_POST['tampilkan_laporan'])) {

    $dari   = $_POST['dari'];
    $sampai = $_POST['sampai'];

    $hasil = mysqli_query($koneksi,
        "SELECT 
            t.tanggal,
            u.nama AS nasabah,
            j.nama_jenis,
            t.berat,
            t.total,
            p.nama AS petugas
        FROM transaksi t
        LEFT JOIN users u ON t.id_user=u.id_user
        LEFT JOIN jenis_sampah j ON t.id_jenis=j.id_jenis
        LEFT JOIN users p ON t.petugas_input=p.id_user
        WHERE DATE(t.tanggal) BETWEEN '$dari' AND '$sampai'
          AND LOWER(t.jenis_transaksi) LIKE '%setor%'
        ORDER BY t.tanggal ASC"
    );
}

include '../_header.php';
?>

<style>
.btn { padding:6px 12px; color:#fff; border-radius:4px; text-decoration:none; }
.btn-green { background:#28a745; }
.btn-red { background:#dc3545; }
</style>

<div class="content">
<h2>LAPORAN PETUGAS</h2>


<!-- ==========================================================
     PERMINTAAN PENARIKAN SALDO
     ========================================================== -->
<div class="card" style="padding:15px;">
    <h3>Daftar Permintaan Penarikan Saldo</h3>

    <table class="table" border="1" cellpadding="6">
        <tr>
            <th>Nama</th>
            <th>Nominal</th>
            <th>Tanggal</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>

        <?php while ($r = mysqli_fetch_assoc($penarikan)): ?>
        <tr>
            <td><?= $r['nama'] ?></td>
            <td>Rp <?= number_format($r['nominal']) ?></td>
            <td><?= $r['tanggal'] ?></td>
            <td><?= $r['status'] ?></td>

            <td>
            <?php if (strtolower($r['status']) === 'menunggu'): ?>

                <a href="laporan.php?setujui=<?= $r['id_penarikan'] ?>"
                   class="btn btn-green"
                   onclick="return confirm('Setujui permintaan ini?')">✔ Setujui</a>

                <a href="laporan.php?tolak=<?= $r['id_penarikan'] ?>"
                   class="btn btn-red"
                   onclick="return confirm('Tolak permintaan ini?')">✖ Tolak</a>

            <?php else: ?>
                <span style="color:gray;">Selesai</span>
            <?php endif; ?>
            </td>
        </tr>
        <?php endwhile; ?>

    </table>
</div>


<br>


<!-- ==========================================================
     FORM FILTER LAPORAN SETORAN
     ========================================================== -->
<h3>Laporan Transaksi (Setoran)</h3>

<form method="post" class="card" style="padding:15px;">
    <label>Dari Tanggal:</label>
    <input type="date" name="dari" required>

    <label>Sampai Tanggal:</label>
    <input type="date" name="sampai" required>

    <button type="submit" name="tampilkan_laporan">Tampilkan Laporan</button>
</form>

<?php if ($hasil): ?>

<br>

<button onclick="window.print()" style="background:#10a37f;color:#fff;padding:8px 15px;border:none;border-radius:5px;">
    Cetak Laporan
</button>

<input type="text" id="cari" placeholder="Cari data..." style="padding:8px;width:250px;margin-bottom:10px;">


<div class="card" id="tableArea">
<h3>Hasil Laporan</h3>

<table class="table" id="tabelLaporan">
    <tr>
        <th>Tanggal</th>
        <th>Nasabah</th>
        <th>Jenis Sampah</th>
        <th>Berat (Kg)</th>
        <th>Total (Rp)</th>
        <th>Petugas</th>
    </tr>

    <?php
    $total_berat = 0;
    $total_uang = 0;
    while ($r = mysqli_fetch_assoc($hasil)):
        $total_berat += $r['berat'];
        $total_uang  += $r['total'];
    ?>
    <tr>
        <td><?= $r['tanggal'] ?></td>
        <td><?= $r['nasabah'] ?></td>
        <td><?= $r['nama_jenis'] ?></td>
        <td><?= number_format($r['berat'], 0) ?> Kg</td>
        <td>Rp <?= number_format($r['total']) ?></td>
        <td><?= $r['petugas'] ?></td>
    </tr>
    <?php endwhile; ?>

    <tr style="font-weight:bold;background:#eee;">
        <td colspan="3">TOTAL</td>
        <td><?= number_format($total_berat, 0) ?> Kg</td>
        <td>Rp <?= number_format($total_uang) ?></td>
        <td></td>
    </tr>

</table>
</div>

<?php endif; ?>

</div>


<script>
document.getElementById("cari").addEventListener("keyup", function () {
    let q = this.value.toLowerCase();
    document.querySelectorAll("#tabelLaporan tr").forEach((row, i) => {
        if (i === 0) return;
        row.style.display = row.textContent.toLowerCase().includes(q) ? "" : "none";
    });
});
</script>

<style>
@media print {
    .sidebar, .header, form, #cari, button { display:none !important; }
}
</style>

<?php include '../_footer.php'; ?>

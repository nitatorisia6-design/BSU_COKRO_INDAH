<?php
session_start();
include '../koneksi.php';

// Cek login sebagai petugas
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'petugas') {
    header('Location: ../index.php');
    exit;
}

/* ================================================================
   HITUNG TOTAL SAMPAH (HANYA SETORAN)
   ================================================================ */
$t1 = mysqli_fetch_assoc(mysqli_query(
    $koneksi,
    "SELECT SUM(berat) AS total FROM transaksi WHERE jenis_transaksi='setoran'"
));

/* ================================================================
   HITUNG TOTAL SALDO NASABAH (setoran - penarikan)
   ================================================================ */
$t3 = mysqli_fetch_assoc(mysqli_query(
    $koneksi,
    "SELECT 
        (SELECT IFNULL(SUM(total),0) FROM transaksi WHERE jenis_transaksi='setoran') -
        (SELECT IFNULL(SUM(nominal),0) FROM penarikan WHERE status='disetujui')
        AS total_saldo"
));

?>
<?php include '../_header.php'; ?>

<div class="content">
    <h1>Dashboard Petugas</h1>

    <div class="card-row">

        <div class="card">
            <h3>Total Sampah</h3>
            <p style="font-size:26px;">
                <?= number_format($t1['total'] ?? 0, 0) ?> Kg
            </p>
        </div>

        <div class="card">
            <h3>Total Saldo Seluruh Nasabah</h3>
            <p style="font-size:26px;">
                Rp <?= number_format($t3['total_saldo'] ?? 0) ?>
            </p>
        </div>

    </div>

    <div class="card">
        <h3>Riwayat Setoran Terbaru</h3>

        <table class="table">
            <tr>
                <th>Tanggal</th>
                <th>Nasabah</th>
                <th>Jenis Sampah</th>
                <th>Berat</th>
                <th>Total</th>
            </tr>

            <?php
            // AMBIL DATA SETORAN TERBARU
            $q = mysqli_query(
                $koneksi,
                "SELECT 
                    t.*, 
                    u.nama AS nasabah, 
                    j.nama_jenis
                 FROM transaksi t
                 LEFT JOIN users u ON t.id_user = u.id_user
                 LEFT JOIN jenis_sampah j ON t.id_jenis = j.id_jenis
                 WHERE t.jenis_transaksi='setoran'
                 ORDER BY t.tanggal DESC
                 LIMIT 5"
            );

            while ($r = mysqli_fetch_assoc($q)):
            ?>
            <tr>
                <td><?= $r['tanggal'] ?></td>
                <td><?= $r['nasabah'] ?></td>
                <td><?= $r['nama_jenis'] ?></td>

                <!-- TIDAK PAKAI 5.00, LANGSUNG 5 -->
                <td><?= number_format($r['berat'], 0) ?> Kg</td>

                <td>Rp <?= number_format($r['total']) ?></td>
            </tr>
            <?php endwhile; ?>

        </table>
    </div>

</div>

<?php include '../_footer.php'; ?>

<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

/* ===== TAMBAH ===== */
if (isset($_POST['tambah'])) {
    $nama  = $_POST['nama_jenis'];
    $harga = $_POST['harga'];

    mysqli_query($koneksi,
        "INSERT INTO jenis_sampah (nama_jenis, harga) VALUES ('$nama','$harga')"
    );

    header("Location: jenis_sampah.php");
    exit;
}

/* ===== EDIT ===== */
if (isset($_POST['edit'])) {
    $id    = $_POST['id_jenis'];
    $nama  = $_POST['nama_jenis'];
    $harga = $_POST['harga'];

    mysqli_query($koneksi,
        "UPDATE jenis_sampah SET nama_jenis='$nama', harga='$harga' WHERE id_jenis='$id'"
    );

    header("Location: jenis_sampah.php");
    exit;
}

/* ===== HAPUS ===== */
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM jenis_sampah WHERE id_jenis='$id'");
    header("Location: jenis_sampah.php");
    exit;
}

/* DATA */
$data = mysqli_query($koneksi, "SELECT * FROM jenis_sampah ORDER BY id_jenis DESC");

/* MODE EDIT */
$edit_mode = false;
$edit_data = null;
if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_data = mysqli_fetch_assoc(
        mysqli_query($koneksi, "SELECT * FROM jenis_sampah WHERE id_jenis=".$_GET['edit'])
    );
}
?>

<?php include '../_header.php'; ?>

<div class="content">
  <h2>Kelola Jenis Sampah</h2>

  <!-- FORM -->
  <div class="card form-card">
    <h3><?= $edit_mode ? 'Edit Jenis Sampah' : 'Tambah Jenis Sampah' ?></h3>

    <form method="post">
      <?php if ($edit_mode): ?>
        <input type="hidden" name="id_jenis" value="<?= $edit_data['id_jenis'] ?>">
      <?php endif; ?>

      <div class="form-group">
        <label>Nama Jenis Sampah</label>
        <input type="text" name="nama_jenis"
               value="<?= $edit_mode ? $edit_data['nama_jenis'] : '' ?>"
               placeholder="Contoh: Plastik" required>
      </div>

      <div class="form-group">
        <label>Harga per Kg</label>
        <input type="number" name="harga"
               value="<?= $edit_mode ? $edit_data['harga'] : '' ?>"
               placeholder="1000" required>
      </div>

      <div class="form-action">
        <button type="submit" name="<?= $edit_mode ? 'edit' : 'tambah' ?>" class="btn-primary">
          <?= $edit_mode ? 'Update' : 'Tambah' ?>
        </button>

        <?php if ($edit_mode): ?>
          <a href="jenis_sampah.php" class="btn-secondary">Batal</a>
        <?php endif; ?>
      </div>
    </form>
  </div>

  <!-- TABEL -->
  <div class="card">
    <h3>Daftar Jenis Sampah</h3>

    <table class="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Nama Jenis Sampah</th>
          <th>Harga / Kg</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php while($r = mysqli_fetch_assoc($data)): ?>
        <tr>
          <td><?= $r['id_jenis'] ?></td>
          <td><?= $r['nama_jenis'] ?></td>
          <td>Rp <?= number_format($r['harga']) ?></td>
          <td>
            <a href="?edit=<?= $r['id_jenis'] ?>" class="link-edit">Edit</a>
            <a href="?hapus=<?= $r['id_jenis'] ?>"
               onclick="return confirm('Hapus data ini?')" class="link-hapus">Hapus</a>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include '../_footer.php'; ?>

<style>
/* CARD */
.card {
  background:#fff;
  padding:20px;
  border-radius:12px;
  margin-bottom:20px;
  box-shadow:0 4px 12px rgba(0,0,0,.1);
}
.form-card {
  max-width:480px;
}

/* FORM */
.form-group {
  display:flex;
  flex-direction:column;
  margin-bottom:15px;
}
.form-group label {
  font-weight:600;
  margin-bottom:6px;
}
.form-group input {
  padding:10px;
  border-radius:6px;
  border:1px solid #ccc;
}
.form-action {
  display:flex;
  gap:10px;
  margin-top:10px;
}

/* BUTTON */
.btn-primary {
  background:#0b2a5c;
  color:#fff;
  border:none;
  padding:10px 16px;
  border-radius:6px;
  cursor:pointer;
}
.btn-secondary {
  background:#ccc;
  padding:10px 16px;
  border-radius:6px;
  color:#000;
  text-decoration:none;
}

/* TABLE */
.table {
  width:100%;
  border-collapse:collapse;
}
.table th, .table td {
  padding:10px;
  border-bottom:1px solid #ddd;
}
.table thead {
  background:#eef2ff;
}

/* LINKS */
.link-edit {
  color:#0b2a5c;
  margin-right:8px;
}
.link-hapus {
  color:red;
}
</style>

<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// ========= PROSES TAMBAH =========
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama_jenis'];
    $harga = $_POST['harga'];

    mysqli_query($koneksi, 
        "INSERT INTO jenis_sampah (nama_jenis, harga) VALUES ('$nama', '$harga')"
    );

    echo "<script>alert('Jenis sampah berhasil ditambahkan'); window.location='jenis_sampah.php';</script>";
    exit;
}

// ========= PROSES EDIT =========
if (isset($_POST['edit'])) {
    $id = $_POST['id_jenis'];
    $nama = $_POST['nama_jenis'];
    $harga = $_POST['harga'];

    mysqli_query($koneksi, 
        "UPDATE jenis_sampah SET nama_jenis='$nama', harga='$harga' WHERE id_jenis=$id"
    );

    echo "<script>alert('Data berhasil diperbarui'); window.location='jenis_sampah.php';</script>";
    exit;
}

// ========= PROSES HAPUS =========
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];

    mysqli_query($koneksi, "DELETE FROM jenis_sampah WHERE id_jenis=$id");

    echo "<script>alert('Data berhasil dihapus'); window.location='jenis_sampah.php';</script>";
    exit;
}

// AMBIL DATA
$data = mysqli_query($koneksi, "SELECT * FROM jenis_sampah ORDER BY id_jenis DESC");

// AMBIL DATA UNTUK MODE EDIT
$edit_mode = false;
$edit_data = null;

if (isset($_GET['edit'])) {
    $edit_mode = true;
    $id_edit = $_GET['edit'];
    $edit_data = mysqli_fetch_assoc(mysqli_query($koneksi, 
        "SELECT * FROM jenis_sampah WHERE id_jenis=$id_edit"
    ));
}

?>
<?php include '../_header.php'; ?>

<div class="content">
    <h2>Kelola Jenis Sampah</h2>

    <!-- FORM TAMBAH / EDIT -->
    <div class="card" style="max-width:500px; margin-bottom:20px;">

        <?php if ($edit_mode): ?>
        <!-- MODE EDIT -->
        <h3>Edit Jenis Sampah</h3>
        <form method="POST">
            <input type="hidden" name="id_jenis" value="<?= $edit_data['id_jenis'] ?>">

            <label>Nama Jenis Sampah</label>
            <input type="text" name="nama_jenis" class="form" 
                value="<?= $edit_data['nama_jenis'] ?>" required>

            <label>Harga per Kg</label>
            <input type="number" name="harga" class="form" 
                value="<?= $edit_data['harga'] ?>" required>

            <button type="submit" name="edit" 
                style="padding:10px;background:#0b2a5c;color:white;border:none;border-radius:6px;margin-top:10px;">
                Update
            </button>

            <a href="jenis_sampah.php" 
                style="padding:10px;background:#ccc;color:black;border-radius:6px;margin-left:10px;">Batal</a>
        </form>

        <?php else: ?>
        <!-- MODE TAMBAH -->
        <h3>Tambah Jenis Sampah</h3>
        <form method="POST">

            <label>Nama Jenis Sampah</label>
            <input type="text" name="nama_jenis" class="form" placeholder="Contoh: Plastik" required>

            <label>Harga per Kg</label>
            <input type="number" name="harga" class="form" placeholder="1000" required>

            <button type="submit" name="tambah" 
                style="padding:10px;background:#0b2a5c;color:white;border:none;border-radius:6px;margin-top:10px;">
                Tambah
            </button>
        </form>
        <?php endif; ?>

    </div>

    <!-- TABEL DATA -->
    <table class="table">
        <tr>
            <th>ID</th>
            <th>Nama Jenis Sampah</th>
            <th>Harga per Kg</th>
            <th>Aksi</th>
        </tr>

        <?php while($r = mysqli_fetch_assoc($data)): ?>
        <tr>
            <td><?= $r['id_jenis'] ?></td>
            <td><?= $r['nama_jenis'] ?></td>
            <td>Rp <?= number_format($r['harga']) ?></td>
            <td>
                <a href="jenis_sampah.php?edit=<?= $r['id_jenis'] ?>" style="color:blue;">Edit</a> | 
                <a href="jenis_sampah.php?hapus=<?= $r['id_jenis'] ?>" 
                   onclick="return confirm('Hapus data ini?')" style="color:red;">Hapus</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

</div>

<?php include '../_footer.php'; ?>

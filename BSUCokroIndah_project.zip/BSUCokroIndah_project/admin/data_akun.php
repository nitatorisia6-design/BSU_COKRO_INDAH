<?php
session_start();
include '../koneksi.php'; // path ke folder utama
include '../_header.php'; // path ke folder utama

// Cek role admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// Tambah akun
if (isset($_POST['add'])) {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $pass = md5($_POST['password']);
    $role = $_POST['role'];
    mysqli_query($koneksi, "INSERT INTO users (nama, username, password, role) VALUES ('$nama','$username','$pass','$role')");
    header('Location: data_akun.php'); // redirect ke halaman yang sama
    exit;
}

// Update akun
if (isset($_POST['edit'])) {
    $id = $_POST['id_user'];
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $role = $_POST['role'];
    if (!empty($_POST['password'])) {
        $pass = md5($_POST['password']);
        mysqli_query($koneksi, "UPDATE users SET nama='$nama', username='$username', password='$pass', role='$role' WHERE id_user='$id'");
    } else {
        mysqli_query($koneksi, "UPDATE users SET nama='$nama', username='$username', role='$role' WHERE id_user='$id'");
    }
    header('Location: data_akun.php');
    exit;
}

// Hapus akun
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM users WHERE id_user='$id'");
    header('Location: data_akun.php');
    exit;
}

// Ambil semua data akun
$users = mysqli_query($koneksi, "SELECT * FROM users");
?>

<div class="content">
  <h2>Data Akun</h2>

  <!-- Form Tambah / Edit -->
  <?php if(isset($_GET['edit'])): 
      $id_edit = $_GET['edit'];
      $row = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM users WHERE id_user='$id_edit'"));
  ?>
    <h3>Edit Akun</h3>
    <form method="post" action="data_akun.php">
      <input type="hidden" name="id_user" value="<?= $row['id_user'] ?>">
      <input name="nama" placeholder="Nama" value="<?= $row['nama'] ?>" required>
      <input name="username" placeholder="Username" value="<?= $row['username'] ?>" required>
      <input name="password" placeholder="Password (kosongkan jika tidak diubah)">
      <select name="role">
        <option value="nasabah" <?= $row['role']=='nasabah'?'selected':'' ?>>Nasabah</option>
        <option value="petugas" <?= $row['role']=='petugas'?'selected':'' ?>>Petugas</option>
        <option value="admin" <?= $row['role']=='admin'?'selected':'' ?>>Admin</option>
      </select>
      <button name="edit" type="submit">Simpan</button>
    </form>
  <?php else: ?>
    <h3>Tambah Akun</h3>
    <form method="post" action="data_akun.php">
      <input name="nama" placeholder="Nama" required>
      <input name="username" placeholder="Username" required>
      <input name="password" placeholder="Password" required>
      <select name="role">
        <option value="nasabah">Nasabah</option>
        <option value="petugas">Petugas</option>
        <option value="admin">Admin</option>
      </select>
      <button name="add" type="submit">Tambah</button>
    </form>
  <?php endif; ?>

  <!-- Tabel Data Akun -->
  <table class="table">
    <tr><th>ID</th><th>Nama</th><th>Username</th><th>Role</th><th>Aksi</th></tr>
    <?php while($u = mysqli_fetch_assoc($users)): ?>
      <tr>
        <td><?= $u['id_user'] ?></td>
        <td><?= $u['nama'] ?></td>
        <td><?= $u['username'] ?></td>
        <td><?= $u['role'] ?></td>
        <td>
          <a href="data_akun.php?edit=<?= $u['id_user'] ?>">Edit</a> |
          <a href="data_akun.php?hapus=<?= $u['id_user'] ?>" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
        </td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>

<?php include '../_footer.php'; ?>

<?php
include "../koneksi.php";
if (!isset($_SESSION)) session_start();

/* =======================
   CEK LOGIN & ROLE ADMIN
======================= */
$user = $_SESSION['user'] ?? null;
$role = $user['role'] ?? '';

if ($role !== 'admin') {
    header("Location: /BSUCokroIndah_project/login.php");
    exit;
}

/* =======================
   AMBIL DATA
======================= */
$jenis_sampah = mysqli_query($koneksi, "SELECT * FROM jenis_sampah");

$qPengaturan = mysqli_query($koneksi, "SELECT * FROM pengaturan WHERE id=1");
$pengaturan  = mysqli_fetch_assoc($qPengaturan) ?? [
    'minimal_setoran'   => 10000,
    'maksimal_nasabah'  => 500,
    'tema'              => 'default'
];

/* =======================
   SIMPAN PERUBAHAN
======================= */
$pesan = '';
if (isset($_POST['simpan'])) {
    $min_setor   = (int) $_POST['min_setor'];
    $max_nasabah = (int) $_POST['max_nasabah'];

    mysqli_query($koneksi, "UPDATE pengaturan SET 
        minimal_setoran   = '$min_setor',
        maksimal_nasabah  = '$max_nasabah'
        WHERE id = 1
    ");

    $pesan = "Pengaturan berhasil disimpan!";
}
?>

<?php include "../_header.php"; ?>

<div class="content">

<h1 style="font-size:32px; color:#0b2a5c;">Pengaturan Sistem</h1>
<p>Atur konfigurasi sistem sesuai kebutuhan operasional</p>

<?php if ($pesan): ?>
<div style="background:#d4ffd4; padding:10px; border-left:5px solid #1a8f1a; border-radius:6px; margin-bottom:14px;">
    <?= $pesan ?>
</div>
<?php endif; ?>

<form method="POST">

<div style="display:flex; gap:20px; flex-wrap:wrap;">

<!-- =======================
     PENGATURAN HARGA SAMPAH
======================= -->
<div class="card" style="flex:1; min-width:330px;">
    <h3>Pengaturan Harga Sampah</h3>

    <table class="table">
        <tr>
            <th>Jenis Sampah</th>
            <th>Harga</th>
        </tr>

        <?php if ($jenis_sampah && mysqli_num_rows($jenis_sampah) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($jenis_sampah)): ?>
            <tr>
                <td><?= htmlspecialchars($row['nama_jenis']) ?></td>
                <td>Rp <?= number_format($row['harga']) ?></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="2">Belum ada data sampah</td>
            </tr>
        <?php endif; ?>
    </table>

    <button type="button"
        onclick="window.location='jenis_sampah.php'"
        style="margin-top:10px; padding:10px; width:100%;
        background:#0b2a5c; color:white; border:none; border-radius:6px;">
        Tambah Jenis Sampah
    </button>
</div>

</div>

<br>

<div style="display:flex; gap:20px; flex-wrap:wrap;">

<!-- =======================
     PENGATURAN SISTEM UMUM
======================= -->
<div class="card" style="flex:1; min-width:330px;">
    <h3>Pengaturan Sistem Umum</h3>

    <label>Minimal Setoran</label>
    <input type="number" name="min_setor" class="form"
        value="<?= htmlspecialchars($pengaturan['minimal_setoran']) ?>">

    <br><br>

    <label>Maksimal Nasabah</label>
    <input type="number" name="max_nasabah" class="form"
        value="<?= htmlspecialchars($pengaturan['maksimal_nasabah']) ?>">
</div>

<!-- =======================
     BACKUP & RESET DATA
======================= -->
<div class="card" style="flex:1; min-width:330px;">
    <h3>Backup & Reset Data</h3>

    <button type="button" onclick="window.location='../backup.php'"
        style="padding:10px; width:100%; background:#0b2a5c; color:white; border:none; border-radius:6px;">
        Backup Data Sekarang
    </button>

    <br><br>

    <button type="button" onclick="confirmReset()"
        style="padding:10px; width:100%; background:#ff5252; color:white; border:none; border-radius:6px;">
        Reset Sistem
    </button>
</div>

</div>

<br><br>

<button name="simpan"
style="padding:10px 20px; background:#0b2a5c; color:white;
border:none; border-radius:8px; font-size:13px;">
    Simpan Perubahan
</button>

</form>

</div>

<script>
function confirmReset() {
    if (confirm("Apakah anda yakin ingin mereset sistem? Semua data akan hilang!")) {
        window.location = "../reset.php";
    }
}
</script>

<?php include "../_footer.php"; ?>

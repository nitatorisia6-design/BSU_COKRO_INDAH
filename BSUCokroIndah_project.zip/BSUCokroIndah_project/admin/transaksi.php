<?php
session_start();
include '../koneksi.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') { header('Location: ../index.php'); exit; }
$q = mysqli_query($koneksi, "SELECT t.*, u.nama as nasabah, j.nama_jenis FROM transaksi t LEFT JOIN users u ON t.id_user=u.id_user LEFT JOIN jenis_sampah j ON t.id_jenis=j.id_jenis ORDER BY tanggal DESC");
?>
<?php include '../_header.php'; ?>
<div class="content">
  <h2>Transaksi</h2>
  <table class="table">
    <tr><th>ID</th><th>Tanggal</th><th>Nasabah</th><th>Jenis</th><th>Berat</th><th>Total</th></tr>
    <?php while($r = mysqli_fetch_assoc($q)): ?>
      <tr>
        <td><?= $r['id_transaksi'] ?></td>
        <td><?= $r['tanggal'] ?></td>
        <td><?= $r['nasabah'] ?></td>
        <td><?= $r['nama_jenis'] ?></td>
        <td><?= $r['berat'] ?></td>
        <td>Rp <?= number_format($r['total']) ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
<?php include '../_footer.php'; ?>

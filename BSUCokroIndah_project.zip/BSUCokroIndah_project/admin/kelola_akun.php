<?php
session_start();
include '../koneksi.php';
include '../_header.php';

// Cek role admin
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

// Tambah akun
if (isset($_POST['add'])) {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $pass = md5($_POST['password']);
    $role = $_POST['role'];
    mysqli_query($koneksi, "INSERT INTO users (nama, username, password, role)
                            VALUES ('$nama','$username','$pass','$role')");
    header('Location: kelola_akun.php');
    exit;
}

// Update akun
if (isset($_POST['edit'])) {
    $id = $_POST['id_user'];
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $role = $_POST['role'];

    if (!empty($_POST['password'])) {
        $pass = md5($_POST['password']);
        mysqli_query($koneksi, "UPDATE users 
            SET nama='$nama', username='$username', password='$pass', role='$role'
            WHERE id_user='$id'");
    } else {
        mysqli_query($koneksi, "UPDATE users 
            SET nama='$nama', username='$username', role='$role'
            WHERE id_user='$id'");
    }
    header('Location: kelola_akun.php');
    exit;
}

// Hapus akun
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM users WHERE id_user='$id'");
    header('Location: kelola_akun.php');
    exit;
}

// Ambil data akun
$users = mysqli_query($koneksi, "SELECT * FROM users");
?>

<div class="content">
<h2>Kelola Akun</h2>

<?php if(isset($_GET['edit'])):
$id_edit = $_GET['edit'];
$row = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT * FROM users WHERE id_user='$id_edit'"));
?>

<h3>Edit Akun</h3>
<form method="post" class="form-akun">
    <input type="hidden" name="id_user" value="<?= $row['id_user'] ?>">

    <div class="form-row">
        <div class="form-group">
            <label>Nama</label>
            <input name="nama" value="<?= $row['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label>Username</label>
            <input name="username" value="<?= $row['username'] ?>" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group password-wrapper">
            <label>Password</label>
            <input type="password" name="password" id="passwordEdit" placeholder="Kosongkan jika tidak diubah">
            <span class="toggle-password" onclick="togglePassword('passwordEdit')">👁️</span>
        </div>
        <div class="form-group">
            <label>Role</label>
            <select name="role">
                <option value="nasabah" <?= $row['role']=='nasabah'?'selected':'' ?>>Nasabah</option>
                <option value="petugas" <?= $row['role']=='petugas'?'selected':'' ?>>Petugas</option>
                <option value="admin" <?= $row['role']=='admin'?'selected':'' ?>>Admin</option>
            </select>
        </div>
    </div>

    <button name="edit" class="btn-primary">Simpan</button>
</form>

<?php else: ?>

<h3>Tambah Akun</h3>
<form method="post" class="form-akun">
    <div class="form-row">
        <div class="form-group">
            <label>Nama</label>
            <input name="nama" required>
        </div>
        <div class="form-group">
            <label>Username</label>
            <input name="username" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group password-wrapper">
            <label>Password</label>
            <input type="password" name="password" id="passwordTambah" required>
            <span class="toggle-password" onclick="togglePassword('passwordTambah')">👁️</span>
        </div>
        <div class="form-group">
            <label>Role</label>
            <select name="role">
                <option value="nasabah">Nasabah</option>
                <option value="petugas">Petugas</option>
                <option value="admin">Admin</option>
            </select>
        </div>
    </div>

    <button name="add" class="btn-primary">Tambah</button>
</form>

<?php endif; ?>

<table class="table">
<tr>
<th>ID</th>
<th>Nama</th>
<th>Username</th>
<th>Role</th>
<th>Aksi</th>
</tr>

<?php while($u = mysqli_fetch_assoc($users)): ?>
<tr>
<td><?= $u['id_user'] ?></td>
<td><?= $u['nama'] ?></td>
<td><?= $u['username'] ?></td>
<td><?= $u['role'] ?></td>
<td>
<a href="kelola_akun.php?edit=<?= $u['id_user'] ?>">Edit</a> |
<a href="kelola_akun.php?hapus=<?= $u['id_user'] ?>" 
   onclick="return confirm('Yakin ingin menghapus akun?')">Hapus</a>
</td>
</tr>
<?php endwhile; ?>
</table>
</div>

<style>
.form-akun {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    max-width: 750px;
    margin-bottom: 25px;
}

.form-row {
    display: flex;
    gap: 15px;
    margin-bottom: 15px;
}

.form-group {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.form-group label {
    font-weight: 600;
    margin-bottom: 5px;
}

.form-group input,
.form-group select {
    padding: 8px 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.password-wrapper {
    position: relative;
}

.toggle-password {
    position: absolute;
    right: 10px;
    top: 35px;
    cursor: pointer;
}

.btn-primary {
    background: #0d6efd;
    color: white;
    border: none;
    padding: 8px 20px;
    border-radius: 5px;
    cursor: pointer;
}

.btn-primary:hover {
    background: #0b5ed7;
}

.table {
    width: 100%;
    border-collapse: collapse;
    background: white;
}

.table th, .table td {
    padding: 10px;
    border-bottom: 1px solid #ddd;
}

.table th {
    background: #e9f0ff;
}
</style>

<script>
function togglePassword(id) {
    const input = document.getElementById(id);
    input.type = input.type === "password" ? "text" : "password";
}
</script>

<?php include '../_footer.php'; ?>

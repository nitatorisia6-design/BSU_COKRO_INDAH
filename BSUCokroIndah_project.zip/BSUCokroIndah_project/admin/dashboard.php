<?php
session_start();
include '../koneksi.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php'); exit;
}
$user = $_SESSION['user'];
$t1 = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(berat) AS total FROM transaksi"));
$t2 = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM users WHERE role='nasabah'"));
$t3 = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(saldo) AS total FROM users"));
?>
<?php include '../_header.php'; ?>
<div class="content">
  <h1>Selamat Datang !</h1>
  <div class="card-row">
    <div class="card">
      <h3>Total Sampah</h3>
      <p style="font-size:26px;"><?= $t1['total'] ?? 0 ?> kg</p>
    </div>
    <div class="card">
      <h3>Jumlah Nasabah</h3>
      <p style="font-size:26px;"><?= $t2['total'] ?></p>
    </div>
    <div class="card">
      <h3>Total Saldo</h3>
      <p style="font-size:26px;">Rp <?= number_format($t3['total'] ?? 0) ?></p>
    </div>
  </div>

  <div class="card">
    <h3>Aktivitas Terbaru</h3>
    <table class="table">
      <tr><th>Tanggal</th><th>Aktivitas</th></tr>
      <?php
      $q = mysqli_query($koneksi, "SELECT * FROM transaksi ORDER BY tanggal DESC LIMIT 5");
      while($r = mysqli_fetch_assoc($q)){
        echo '<tr><td>'.$r['tanggal'].'</td><td>'.$r['jenis_transaksi'].' Rp '.number_format($r['total']).'</td></tr>';
      }
      ?>
    </table>
  </div>
</div>
<?php include '../_footer.php'; ?>

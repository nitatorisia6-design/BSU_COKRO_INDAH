<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) 
    || $_SESSION['user']['role'] !== 'admin') {

    header('Location: ../index.php');
    exit;
}

$hasil = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $dari   = $_POST['dari'];
    $sampai = $_POST['sampai'];

    $hasil = mysqli_query($koneksi,
        "SELECT t.*, u.nama AS nasabah, j.nama_jenis, p.nama AS petugas
         FROM transaksi t
         LEFT JOIN users u ON t.id_user = u.id_user
         LEFT JOIN jenis_sampah j ON t.id_jenis = j.id_jenis
         LEFT JOIN users p ON t.petugas_input = p.id_user
         WHERE DATE(t.tanggal) BETWEEN '$dari' AND '$sampai'
         ORDER BY t.tanggal ASC"
    );
}
?>

<?php include '../_header.php'; ?>

<div class="content">
  <h2>Laporan Transaksi Petugas</h2>

  <form method="post" class="card" style="padding:15px;">
    <label>Dari Tanggal:</label>
    <input type="date" name="dari" required>

    <label>Sampai Tanggal:</label>
    <input type="date" name="sampai" required>

    <button type="submit">Tampilkan Laporan</button>
  </form>

  <?php if ($hasil): ?>
    <br>

    <!-- Tombol Cetak -->
    <button onclick="window.print()" 
            style="background:#10a37f;color:#fff;padding:8px 15px;border:none;border-radius:5px;margin-bottom:10px;cursor:pointer;">
      Cetak Laporan
    </button>

    <!-- Kolom Pencarian -->
    <input type="text" id="cari" placeholder="Cari data..." 
           style="padding:8px;width:250px;margin-bottom:10px;">

    <div class="card" id="tableArea">
      <h3>Hasil Laporan</h3>

      <table class="table" id="tabelLaporan">
        <tr>
          <th>Tanggal</th>
          <th>Nasabah</th>
          <th>Jenis Sampah</th>
          <th>Berat (Kg)</th>
          <th>Total (Rp)</th>
          <th>Petugas</th>
        </tr>

        <?php 
        $total_berat = 0;
        $total_uang = 0;

        while ($r = mysqli_fetch_assoc($hasil)): 
          $total_berat += $r['berat'];
          $total_uang  += $r['total'];
        ?>
        <tr>
          <td><?= $r['tanggal'] ?></td>
          <td><?= $r['nasabah'] ?></td>
          <td><?= $r['nama_jenis'] ?></td>
          <td><?= $r['berat'] ?> Kg</td>
          <td>Rp <?= number_format($r['total']) ?></td>
          <td><?= $r['petugas'] ?></td>
        </tr>
        <?php endwhile; ?>

        <tr style="font-weight:bold;background:#efefef;">
          <td colspan="3">TOTAL</td>
          <td><?= $total_berat ?> Kg</td>
          <td>Rp <?= number_format($total_uang) ?></td>
          <td></td>
        </tr>
      </table>

    </div>
  <?php endif; ?>

</div>

<?php include '../_footer.php'; ?>

<!-- SCRIPT PENCARIAN -->
<script>
document.getElementById("cari").addEventListener("keyup", function () {
    let input = this.value.toLowerCase();
    let rows = document.querySelectorAll("#tabelLaporan tr");

    rows.forEach((row, index) => {
        if (index === 0) return; // header skip
        let text = row.textContent.toLowerCase();
        row.style.display = text.includes(input) ? "" : "none";
    });
});
</script>

<style>
/* Sembunyikan header & sidebar saat print */
@media print {
  .sidebar, .header, form, #cari, button {
    display: none !important;
  }
  #tableArea {
    margin-top: 20px;
  }
}
</style>

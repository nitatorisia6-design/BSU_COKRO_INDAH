<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}

$hasil = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dari   = $_POST['dari'];
    $sampai = $_POST['sampai'];

    $hasil = mysqli_query($koneksi, "
        SELECT t.*, 
               u.nama AS nasabah, 
               j.nama_jenis, 
               p.nama AS petugas
        FROM transaksi t
        LEFT JOIN users u ON t.id_user = u.id_user
        LEFT JOIN jenis_sampah j ON t.id_jenis = j.id_jenis
        LEFT JOIN users p ON t.petugas_input = p.id_user
        WHERE DATE(t.tanggal) BETWEEN '$dari' AND '$sampai'
        ORDER BY t.tanggal ASC
    ");
}
?>

<?php include '../_header.php'; ?>

<div class="content">
  <h2>Laporan Transaksi Petugas</h2>

  <!-- FORM FILTER -->
  <div class="card">
    <form method="post" class="form-grid">
      <div class="form-group">
        <label>Dari Tanggal</label>
        <input type="date" name="dari" required>
      </div>

      <div class="form-group">
        <label>Sampai Tanggal</label>
        <input type="date" name="sampai" required>
      </div>

      <div class="form-group">
        <label>&nbsp;</label>
        <button type="submit" class="btn-primary">Tampilkan</button>
      </div>
    </form>
  </div>

  <?php if ($hasil): ?>
  <!-- TOOLBAR -->
  <div class="toolbar">
    <button onclick="window.print()" class="btn-print">Cetak</button>
    <input type="text" id="cari" placeholder="Cari data...">
  </div>

  <!-- TABEL -->
  <div class="card" id="tableArea">
    <h3>Hasil Laporan</h3>

    <table class="table" id="tabelLaporan">
      <thead>
        <tr>
          <th>Tanggal</th>
          <th>Nasabah</th>
          <th>Jenis Sampah</th>
          <th>Berat (Kg)</th>
          <th>Total (Rp)</th>
          <th>Petugas</th>
        </tr>
      </thead>
      <tbody>
      <?php
      $total_berat = 0;
      $total_uang  = 0;

      while ($r = mysqli_fetch_assoc($hasil)):
        $total_berat += $r['berat'];
        $total_uang  += $r['total'];
      ?>
        <tr>
          <td><?= date('d-m-Y', strtotime($r['tanggal'])) ?></td>
          <td><?= $r['nasabah'] ?></td>
          <td><?= $r['nama_jenis'] ?></td>
          <td><?= $r['berat'] ?></td>
          <td><?= number_format($r['total']) ?></td>
          <td><?= $r['petugas'] ?></td>
        </tr>
      <?php endwhile; ?>
      </tbody>
      <tfoot>
        <tr>
          <th colspan="3">TOTAL</th>
          <th><?= $total_berat ?> Kg</th>
          <th>Rp <?= number_format($total_uang) ?></th>
          <th></th>
        </tr>
      </tfoot>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php include '../_footer.php'; ?>

<!-- SEARCH -->
<script>
document.getElementById("cari")?.addEventListener("keyup", function () {
    const value = this.value.toLowerCase();
    document.querySelectorAll("#tabelLaporan tbody tr").forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(value) ? "" : "none";
    });
});
</script>

<style>
/* CARD */
.card {
  background:#fff;
  padding:20px;
  border-radius:12px;
  margin-bottom:20px;
  box-shadow:0 4px 12px rgba(0,0,0,.1);
}

/* FORM */
.form-grid {
  display:grid;
  grid-template-columns: repeat(3,1fr);
  gap:15px;
}
.form-group {
  display:flex;
  flex-direction:column;
}
.form-group label {
  font-weight:600;
  margin-bottom:6px;
}
.form-group input {
  padding:10px;
  border:1px solid #ccc;
  border-radius:6px;
}

/* BUTTON */
.btn-primary {
  background:#0b2c5f;
  color:#fff;
  border:none;
  padding:10px;
  border-radius:6px;
  cursor:pointer;
}
.btn-print {
  background:#10a37f;
  color:#fff;
  padding:8px 14px;
  border:none;
  border-radius:6px;
  cursor:pointer;
}

/* TOOLBAR */
.toolbar {
  display:flex;
  justify-content:space-between;
  margin-bottom:10px;
}
.toolbar input {
  padding:8px;
  width:220px;
  border-radius:6px;
  border:1px solid #ccc;
}

/* TABLE */
.table {
  width:100%;
  border-collapse:collapse;
}
.table th, .table td {
  padding:10px;
  border-bottom:1px solid #ddd;
}
.table thead {
  background:#eef2ff;
}
.table tfoot {
  background:#f5f5f5;
  font-weight:bold;
}

/* PRINT */
@media print {
  .sidebar,.header,form,.toolbar { display:none!important; }
  body { background:#fff; }
}
</style>

<?php
session_start();
include '../koneksi.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'nasabah') {
    header('Location: ../index.php');
    exit;
}

$id = $_SESSION['user']['id_user'];

/* ============================================================
   AMBIL SALDO & TOTAL BERAT USER
   ============================================================ */
$user = mysqli_fetch_assoc(
    mysqli_query($koneksi, "SELECT saldo, total_berat FROM users WHERE id_user='$id'")
);

$saldo       = $user['saldo'] ?? 0;
$total_berat = $user['total_berat'] ?? 0;

/* ============================================================
   RIWAYAT SETORAN (DARI TABEL TRANSAKSI)
   ============================================================ */
$riwayat_setoran = mysqli_query(
    $koneksi,
    "SELECT t.*, j.nama_jenis 
     FROM transaksi t
     LEFT JOIN jenis_sampah j ON t.id_jenis = j.id_jenis
     WHERE t.id_user='$id' AND t.jenis_transaksi='setoran'
     ORDER BY t.tanggal DESC"
);

/* ============================================================
   RIWAYAT PENARIKAN (DARI TABEL PENARIKAN)
   ============================================================ */
$riwayat_penarikan = mysqli_query(
    $koneksi,
    "SELECT *
     FROM penarikan
     WHERE id_user='$id'
     ORDER BY tanggal DESC"
);

/* ============================================================
   RIWAYAT TRANSAKSI LENGKAP: SETORAN + PENARIKAN
   ============================================================ */
$riwayat_all = mysqli_query(
    $koneksi,
    "SELECT 
        t.tanggal,
        'setoran' AS jenis_transaksi,
        j.nama_jenis,
        t.berat,
        t.total
     FROM transaksi t
     LEFT JOIN jenis_sampah j ON t.id_jenis=j.id_jenis
     WHERE t.id_user='$id'

     UNION ALL

     SELECT
        p.tanggal,
        'penarikan' AS jenis_transaksi,
        NULL AS nama_jenis,
        NULL AS berat,
        p.nominal AS total
     FROM penarikan p
     WHERE p.id_user='$id'

     ORDER BY tanggal DESC"
);

include '../_header.php';
?>

<div class="content">
    <h1>Saldo Anda</h1>

    <div class="card-row">

        <!-- TOTAL SALDO -->
        <div class="card">
            <h3>Total Saldo</h3>
            <p style="font-size:28px;">Rp <?= number_format($saldo, 0, ',', '.') ?></p>
            <a href="tarik_saldo.php" class="btn btn-primary" style="margin-top:15px;">Tarik Saldo Tunai</a>
        </div>

        <!-- TOTAL BERAT -->
        <div class="card">
            <h3>Total Berat Sampah</h3>
            <p style="font-size:28px;"><?= number_format($total_berat, 0) ?> Kg</p>
        </div>

    </div>

    <!-- RINCIAN SALDO PER JENIS (SETORAN) -->
    <div class="card">
        <h3>Rincian Saldo Per Jenis (Setoran)</h3>

        <table class="table">
            <tr>
                <th>Jenis</th>
                <th>Berat</th>
                <th>Harga/Kg</th>
                <th>Total</th>
            </tr>

            <?php while ($r = mysqli_fetch_assoc($riwayat_setoran)): ?>
            <tr>
                <td><?= $r['nama_jenis'] ?></td>
                <td><?= number_format($r['berat'], 0) ?> Kg</td>
                <td>Rp <?= number_format($r['harga']) ?></td>
                <td>Rp <?= number_format($r['total']) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <!-- RIWAYAT PENARIKAN -->
    <div class="card" style="margin-top:20px;">
        <h3>Riwayat Penarikan Saldo</h3>

        <table class="table">
            <tr>
                <th>Tanggal</th>
                <th>Nominal</th>
                <th>Status</th>
            </tr>

            <?php while ($r = mysqli_fetch_assoc($riwayat_penarikan)): ?>
            <tr>
                <td><?= $r['tanggal'] ?></td>
                <td>Rp <?= number_format($r['nominal']) ?></td>
                <td>
    <?php if ($r['status'] == 'Disetujui'): ?>
        <span style="color:green;">Disetujui</span>

    <?php elseif ($r['status'] == 'Ditolak'): ?>
        <span style="color:red;">Ditolak</span>

    <?php else: ?>
        <span style="color:orange;">Menunggu</span>
    <?php endif; ?>
</td>

            </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <!-- RIWAYAT TRANSAKSI LENGKAP -->
    <div class="card" style="margin-top:20px;">
        <h3>Riwayat Transaksi Lengkap</h3>

        <table class="table">
            <tr>
                <th>Tanggal</th>
                <th>Jenis</th>
                <th>Jenis Sampah</th>
                <th>Berat</th>
                <th>Total</th>
            </tr>

            <?php while ($r = mysqli_fetch_assoc($riwayat_all)): ?>
            <tr>
                <td><?= $r['tanggal'] ?></td>
                <td><?= ucfirst($r['jenis_transaksi']) ?></td>
                <td><?= $r['jenis_transaksi'] == 'penarikan' ? '-' : $r['nama_jenis'] ?></td>
                <td><?= $r['jenis_transaksi'] == 'penarikan' ? '-' : number_format($r['berat'], 0) . ' Kg' ?></td>
                <td>Rp <?= number_format($r['total']) ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<?php include '../_footer.php'; ?>

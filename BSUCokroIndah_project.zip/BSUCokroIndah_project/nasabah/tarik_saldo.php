<?php
session_start();
include '../koneksi.php';

// CEK LOGIN & ROLE
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'nasabah') {
    header("Location: ../index.php");
    exit;
}

$id_user = $_SESSION['user']['id_user'];

// AMBIL SALDO USER
$q = mysqli_query($koneksi, "SELECT saldo FROM users WHERE id_user='$id_user'");
$data = mysqli_fetch_assoc($q);
$saldo = $data['saldo'] ?? 0;

// JIKA USER MENEKAN SUBMIT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nominal = intval($_POST['nominal']);

    // VALIDASI
    if ($nominal < 1000) {
        echo "<script>alert('Minimal penarikan Rp 1.000');window.location='tarik_saldo.php';</script>";
        exit;
    }

    if ($nominal > $saldo) {
        echo "<script>alert('Saldo tidak mencukupi');window.location='tarik_saldo.php';</script>";
        exit;
    }

    // INSERT KE TABEL PENARIKAN (TANPA MENGURANGI SALDO)
    $insert = mysqli_query($koneksi,
        "INSERT INTO penarikan (id_user, nominal, tanggal, status)
         VALUES ('$id_user', '$nominal', NOW(), 'Menunggu')"
    );

    if ($insert) {
        echo "<script>
                alert('Pengajuan penarikan berhasil! Menunggu persetujuan petugas.');
                window.location='saldo.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal membuat pengajuan. Error database.');
                window.location='tarik_saldo.php';
              </script>";
    }
}

include '../_header.php';
?>

<div class='content'>
    <h1>Tarik Saldo Tunai</h1>

    <div class="card" style="padding:20px;">
        <p><b>Saldo Anda:</b> Rp <?= number_format($saldo) ?></p>

        <form method="post">
            <label>Nominal Penarikan:</label>
            <input type="number" name="nominal" required min="1000">

            <button type="submit" class="btn btn-primary" style="margin-top:10px;">
                Ajukan Penarikan
            </button>
        </form>
    </div>
</div>

<?php include '../_footer.php'; ?>

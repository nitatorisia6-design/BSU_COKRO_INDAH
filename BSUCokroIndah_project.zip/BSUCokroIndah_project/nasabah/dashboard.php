<?php
session_start();
include '../koneksi.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'nasabah') {
    header('Location: ../index.php'); 
    exit;
}

$id = $_SESSION['user']['id_user'];

$saldo = mysqli_fetch_assoc(mysqli_query(
    $koneksi,
    "SELECT 
        (SELECT IFNULL(SUM(total),0) FROM transaksi 
         WHERE id_user='$id' AND jenis_transaksi='setoran') 
        -
        (SELECT IFNULL(SUM(nominal),0) FROM penarikan 
         WHERE id_user='$id' AND status='disetujui')
        AS saldo"
));


?>
<?php include '../_header.php'; ?>

<div class="content">
  <h1>Selamat Datang (Nasabah)!</h1>

  <div class="card-row">
    <div class="card">
      <h3>Total Saldo</h3>
      <p style="font-size:26px;">Rp <?= number_format($saldo['saldo'] ?? 0) ?></p>
    </div>
  </div>

  <div class="card">
    <h3>Riwayat Transaksi</h3>
    <table class="table">
      <tr>
        <th>Tanggal</th>
        <th>Jenis</th>
        <th>Berat</th>
        <th>Harga/Kg</th>
        <th>Total</th>
        <th>Transaksi</th>
      </tr>
      <?php
      $q = mysqli_query(
          $koneksi,
          "SELECT t.*, j.nama_jenis 
           FROM transaksi t 
           LEFT JOIN jenis_sampah j ON t.id_jenis=j.id_jenis 
           WHERE t.id_user='$id'
           ORDER BY tanggal DESC"
      );

      while($r = mysqli_fetch_assoc($q)){
        echo '<tr>
          <td>'.$r['tanggal'].'</td>
          <td>'.($r['nama_jenis'] ?? '-').'</td>
          <td>'.$r['berat'].'</td>
          <td>Rp '.number_format($r['harga']).'</td>
          <td>Rp '.number_format($r['total']).'</td>
          <td>'.$r['jenis_transaksi'].'</td>
        </tr>';
      }
      ?>
    </table>
  </div>

</div>

<?php include '../_footer.php'; ?>

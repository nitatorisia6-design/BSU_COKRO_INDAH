<?php
session_start();
include '../koneksi.php';      // koneksi ke database
include '../_header.php';      // header halaman

// Cek role nasabah
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'nasabah') {
    header('Location: ../index.php');
    exit;
}

// Ambil ID user dari session
$id_user = $_SESSION['user']['id_user'];

// Query riwayat setoran per nasabah
$query = "
    SELECT t.*, j.nama_jenis 
    FROM transaksi t
    LEFT JOIN jenis_sampah j ON t.id_jenis = j.id_jenis
    WHERE t.id_user = '$id_user'
    ORDER BY t.tanggal DESC
";
$result = mysqli_query($koneksi, $query);
?>

<div class="content">
    <h2>Riwayat Setoran</h2>
    <table class="table">
        <tr>
            <th>Tanggal</th>
            <th>Jenis Sampah</th>
            <th>Berat (Kg)</th>
            <th>Harga/Kg</th>
            <th>Total</th>
        </tr>
        <?php if(mysqli_num_rows($result) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
                    <td><?= htmlspecialchars($row['nama_jenis']) ?></td>
                    <td><?= number_format($row['berat'], 2) ?></td>
                    <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                    <td>Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr>
                <td colspan="5" style="text-align:center;">Belum ada setoran</td>
            </tr>
        <?php endif; ?>
    </table>
</div>

<?php include '../_footer.php'; ?>
